export const SET_USER_INFO_LIST = 'userHomePage/SET_USER_INFO_LIST'

export const UPDATE_USER_INFO_LIST = 'userHomePage/UPDATE_USER_INFO_LIST'

