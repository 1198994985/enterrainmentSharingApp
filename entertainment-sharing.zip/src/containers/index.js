import ChatView from "./RightView";

import MainView from "./MainView";
import Login from "./LoginPage";
export {
  ChatView,
  MainView,
  Login
};
