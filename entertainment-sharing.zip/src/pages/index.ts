import Home from './home/'
import MusicDetail from "./musicDetail/";
import MvPage from "./mvPage/";
import Temp from './home/temp'
import GamePage from "./gamePage/";

export { Home, MusicDetail, MvPage, Temp, GamePage };