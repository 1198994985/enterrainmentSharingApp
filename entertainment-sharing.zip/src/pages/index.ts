import Home from './home/'
import MusicDetail from "./musicDetail/";
import MvPage from "./mvPage/";

export { Home, MusicDetail, MvPage };