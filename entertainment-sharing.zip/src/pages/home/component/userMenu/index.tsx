import React from 'react'

interface Props {
  
}
//检测是否登陆,检测是否有cookie,
const index: React.FC<Props> = () => {
  return (
    <div>
      
    </div>
  )
}

export default index
