import React, { useEffect, useState } from 'react';
import './index.less'

function ChatContentList(props) {
  return (
    <article className="free-chat-Content">
      
    </article>
  )
  
}

