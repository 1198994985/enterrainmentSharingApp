import React from 'react';
import './index.less'

function ChatHeaders(props) {
  return (
    <header>
      
    </header>
  )
  
}