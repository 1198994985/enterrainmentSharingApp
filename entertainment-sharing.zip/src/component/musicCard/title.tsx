import React from 'react'

interface Props {
  
}

const title: React.FC<Props> = () => {
  return (
    <div>
      
    </div>
  )
}

export default title
